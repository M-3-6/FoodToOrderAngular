import { Component } from '@angular/core';
import {
  FormArray,
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { UserService } from '../../../services/user.service';
import { Observable } from 'rxjs';
import { User } from '../../../models/user';
import { Order } from '../../../models/order';
import { OrderService } from '../../../services/order.service';
import { Dish } from '../../../models/dish';
import { DishService } from '../../../services/dish.service';

@Component({
  selector: 'app-update-order',
  templateUrl: './update-order.component.html',
  styleUrl: './update-order.component.scss',
})
export class UpdateOrderComponent {
  firstOrderFormGroup = this.formBuilder.group({
    id: ['', Validators.required],
    oid: ['', Validators.required],
  });

  secondFormGroup = this.formBuilder.group({
    secondCtrl: ['', Validators.required],
  });

  arrUsers: Observable<User[]>;
  arrOrders: Observable<Order[]> = new Observable<Order[]>();
  currentOrderId: number = 0;

  public dishForm: FormGroup;
  count: number = 0;
  countSecondFormSubmit: number = 0;
  order: Order = new Order(0, '', 0, 0, [], []);
  dish: Dish = new Dish(0, '', 0, '', 0, false);
  idUpdated: number = 0;

  dishes(): FormArray {
    return this.dishForm.get('dishes') as FormArray;
  }

  constructor(
    private formBuilder: FormBuilder,
    private userService: UserService,
    private orderService: OrderService,
    private dishService: DishService
  ) {
    this.arrUsers = this.userService.getUsers();
    this.dishForm = this.formBuilder.group({
      dishes: this.formBuilder.array([]),
    });
  }

  saveFirstStepData(formData: FormGroup) {
    console.log(formData.value);
    // this.restaurant.rName = formData.value.rNameCtrl;
    // //this.restaurant.location = formData.value.rLocationCtrl;
    // this.restaurant.user_id = formData.value.rUserIdCtrl;
  }

  onUserSelected(evt: any) {
    this.arrOrders = this.orderService.getOrdersByUserId(evt.target.value);
    console.log('user id selected');
  }

  onOrderSelected(evt: any) {
    var idObtained = evt.target.value;
    this.idUpdated = parseInt(idObtained.split(':')[0].trim());
    console.log('this.idUpdated', this.idUpdated);

    this.orderService.getOrderById(this.idUpdated).subscribe((data: Order) => {
      this.order = data;
      const dishesFormArray = this.dishForm.get('dishes') as FormArray;
      dishesFormArray.clear();
      this.order.arrDishes.forEach((dish) => {
        const dishFormGroup = this.formBuilder.group({
          dishName: [dish.dishName, Validators.required],
          price: [dish.price, Validators.required],
        });
        dishesFormArray.push(dishFormGroup);
      });
    });
    console.log('order id selected');
  }

  get dishControls() {
    return (this.dishForm.get('dishes') as FormArray).controls;
  }

  // saveSecondStepData(formdata:FormGroup){
  //   this.countSecondFormSubmit++;
  //   if(this.countSecondFormSubmit==this.count){
  //     console.log(formdata);
  //     let dArr = Object.values(formdata);
  //     console.log(dArr[0])

  //     dArr[0].forEach((currDish:any)=>{console.log(currDish)
  //       this.order.arrDishes.push(new Dish(currDish.count++, currDish.dNameCtrl, currDish.imageCtrl, currDish.priceCtrl, this.count , currDish.availableCtrl))
  //     })

  //     console.log(this.order);
  //     this.orderService.addOrder(this.order).subscribe((data: any)=>{
  //       console.log(data)
  //     })
  //   }
  // }

  onSubmit() {
    const id = this.firstOrderFormGroup.get('id')?.value;
    const orderDate = this.firstOrderFormGroup.get('orderDate')?.value;
    const orderAmount = this.firstOrderFormGroup.get('orderAmount')?.value;
    const userId = this.firstOrderFormGroup.get('userId')?.value;

    const dishData = this.dishForm.value.dishes.map((dish: any) => ({
      id: dish.id,
      dishName: dish.dishName,
      price: parseInt(dish.price),
      img_path: dish.img_path,
    }));

    const updatedOrderData = {
      id: id,
      orderDate: orderDate,
      orderAmount: orderAmount,
      userId: userId,
      arrDishes: dishData,
      quantity: [],
    };

    this.orderService.updateOrder(updatedOrderData, id).subscribe(
      (updatedOrder: any) => {
        console.log('Order updated successfully:', updatedOrder);
      },
      (error: any) => {
        console.error('Failed to update order:', error);
      }
    );
  }

  //

  public addDishFormGroup() {
    const dishFormArray = this.formBuilder.group({
      dishName: [''],
      price: [''],
    });
    (this.dishForm.get('dishes') as FormArray).push(dishFormArray);
  }

  public removeOrClearDish(i: number) {
    const dishes = this.dishForm.get('dishes') as FormArray;
    if (dishes.length > 1) {
      dishes.removeAt(i);
    } else {
      dishes.reset();
    }
  }
}