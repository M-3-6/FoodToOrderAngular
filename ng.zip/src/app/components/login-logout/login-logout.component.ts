import { Component } from '@angular/core';

@Component({
  selector: 'app-login-logout',
  templateUrl: './login-logout.component.html',
  styleUrl: './login-logout.component.scss'
})
export class LoginLogoutComponent {
  constructor() {
    localStorage.setItem('role', "");
    localStorage.setItem('userId', "");
  }
}
